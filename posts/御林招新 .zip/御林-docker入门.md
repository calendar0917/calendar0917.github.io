---
title: "御林招新题：docker 入门"
subtitle: "御林招新题：docker 入门"
summary: "学习 docker 的基础操作"
description: "学习 docker 的基础操作"
image: ""
date: 2025-10-19
lastmod: 2025-10-19
draft: false
hiddenFromHomePage: True
toc:
 enable: true
weight: false
categories: ["CTF"]
tags: ["CTF"]
---

## **安装与配置 Docker**

- 在你的 Linux 操作系统上，安装 Docker Engine。
- 配置 Docker 的国内镜像源，以加快镜像下载速度。
- **验证**：执行 `docker version` 和 `docker info` 命令，确认 Docker 已正确安装并配置。

> 参考之前写的：[配置docker](https://calendar0917.github.io/posts/配置docker/)

## **运行你的第一个容器**

- 使用 `docker pull` 命令拉取 `hello-world` 镜像。
- 使用 `docker run` 命令运行一个 `hello-world` 容器，观察其输出。

```shell
[root@localhost ~]# docker run hello-world

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
......
```

- 运行一个 `searxng` 容器。
  - 使用 `docker run` 命令，将 `searxng` 容器运行在后台。
  - 将容器的 `8080` 端口映射到主机的 `8080` 端口。
  - 验证：在浏览器中访问 `http://localhost:8080`，确认 `searxng` 网页正常显示。

```shell
[root@localhost ~]# docker pull searxng/searxng
[root@localhost ~]# docker run -d -p 8080:8080 searxng/searxng
```

> - docker run:
>   - `-d`：后台运行容器（守护进程模式）。
>   - `-p 主机端口:容器端口`：端口映射（外部可通过主机端口访问容器服务）。
>   - `-v 主机目录:容器目录`：挂载数据卷（持久化数据，容器删除后数据不丢失）。
>   - `--name 容器名`：指定容器名称（方便后续操作）。
>   - `-it`：交互式运行（用于进入容器终端，如 `bash`）

![image-20251019075703614](https://raw.githubusercontent.com/calendar0917/images/master/image-20251019075703614.png)

## **核心概念理解**

- **解释题**：请用你自己的话，简要解释以下核心概念，并说明它们之间的关系。
  - **镜像（Image）**
    - 类似安装包，整合了所需的运行环境。创建了就不会被更改。
  - **容器（Container）**
    - 基于镜像安装后的实例应用，而且是独立的，可以启动、删除等等，同时是一个隔离出来的沙箱环境
  - **Dockerfile**
    - 自己构建镜像的工具，在这个文档中编写镜像所需的环境（而非一个一个手动安装），实现自动化构建

## **了解 Docker Compose**

- 什么是 Docker Compose？它解决了什么问题？
  - Docker 官方提供的一个工具，用于定义和运行**多容器** Docker 应用程序。
  - 将多个 docker 容器整合到一起，可以统一操作（而不用一个一个开启、关闭）。并且可以一起配置网络、数据卷挂载等等。
- 简要说明 Docker Compose 文件（`docker-compose.yml`）的作用。
  - Docker Compose 的核心配置文件，具体实现多个 docker 容器的协同。可以定义 compose 中的：
    - 服务：指定适用镜像、映射端口等
    - 网络：使不同容器可以在一个网络中通信
    - 数据卷：在容器之间或者容器与主机之间共享数据

## **编写你的第一个 Dockerfile**

- **挑战**：编写一个 `Dockerfile`，实现以下功能：
  - 基于一个最新的 `ubuntu` 镜像。
  - 在容器中安装 `nginx`。
  - 设置 `nginx` 服务在容器启动时自动运行。
  - **验证**：使用 `docker build` 命令构建你的镜像，并使用 `docker run` 命令运行该容器，确保 `nginx` 服务正在运行。

```dockerfile
# 基于最新的 Ubuntu 镜像
FROM ubuntu:latest

# 安装 nginx
# 首先更新 Ubuntu 的软件包列表，然后安装 nginx，最后清理软件包缓存以减小镜像体积
RUN apt-get update && \
    apt-get install -y nginx && \
    rm -rf /var/lib/apt/lists/*

# 设置 nginx 服务在容器启动时自动运行
# CMD 指令指定容器启动时要执行的命令，这里让 nginx 以前台方式运行，保证容器不退出
CMD ["nginx", "-g", "daemon off;"]
```

```shell
[root@localhost ~]# docker build -t my-ubuntu-nginx .
......

[root@localhost ~]# docker run -d -p 80:80 my-ubuntu-nginx
```

> - 为什么不用下载整个 ubuntu 镜像？
>   - Docker 中的 `ubuntu` 镜像本质是 **“精简的根文件系统（rootfs）”**，仅包含运行 Ubuntu 环境所需的核心组件，共享宿主机的 Linux 内核，只保留基础命令，去除图形化

![image-20251019082929494](https://raw.githubusercontent.com/calendar0917/images/master/image-20251019082929494.png)

## **使用 Docker Compose 部署多服务应用**

- **挑战**：编写一个 `docker-compose.yml` 文件，实现以下功能：
  - **服务一**：部署一个 `nginx` 服务，将其 `80` 端口映射到主机的 `8081` 端口。
  - **服务二**：部署一个 `mysql` 服务，并设置环境变量 `MYSQL_ROOT_PASSWORD`。
  - **验证**：使用 `docker compose up -d` 命令一键启动这两个服务，并使用 `docker ps` 确认两个容器都已成功运行。

```yml
version: '3'
services:
  # 服务一：Nginx 服务
  nginx-service:
    image: nginx:latest
    ports:
      - "8081:80"  # 将容器的 80 端口映射到主机的 8081 端口
  # 服务二：MySQL 服务
  mysql-service:
    image: mysql:latest
    environment:
      MYSQL_ROOT_PASSWORD: 1234
    ports:
      - "3306:3306"
```

```shell
[root@localhost docker_compose_test]# vi docker-compose.yml
[root@localhost docker_compose_test]# docker compose up -d
[root@localhost docker_compose_test]# docker ps
CONTAINER ID   IMAGE          COMMAND                  CREATED         STATUS         PORTS                                   NAMES
70b31fae2377   mysql:latest   "docker-entrypoint.s…"   3 minutes ago   Up 3 minutes   3306/tcp, 33060/tcp                     docker_compose_test-mysql-service-1
d61344588b2e   nginx:latest   "/docker-entrypoint.…"   3 minutes ago   Up 3 minutes   0.0.0.0:8081->80/tcp, :::8081->80/tcp   docker_compose_test-nginx-service-1
```

